//-------------------------------------------------------------------------
//						env
//-------------------------------------------------------------------------
`include "alu_agnt_cfg.sv"
`include "rst_agnt_cfg.sv"
`include "v_sqr.sv"
`include "alu_reset_agent.sv"
`include "alu_agent.sv"
`include "alu_scoreboard.sv"
`include "alu_subscriber.sv"


class alu_env extends uvm_env;

  
  // Virtual ALU interface handle  
  virtual alu_if vif;
  
  // Virtual rst interface handle  
  virtual rst_if r_vif;
  
  env_config env_cfg;
  
  rst_agent_config rst_agnt_cfg;
  alu_agent_config alu_agnt_cfg;
  
  // Component instances
  alu_reset_agent   alu_reset_agnt;
  alu_agent         alu_agnt;
  virtual_sequencer v_seqr;
  alu_scoreboard    alu_scb;
  alu_subscriber    alu_sub;
  uvm_port_list     list;
  uvm_analysis_port #(alu_reset_seq_item) reset_collected_port_n;
  uvm_analysis_port #(alu_reset_seq_item) reset_collected_port_p;


  // Register with factory
  `uvm_component_utils(alu_env)

  //---------------------------------------
  // Constructor
  //---------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  //---------------------------------------
  // Build phase
  //---------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // Create Reset Agent Component and TLM Component
    reset_collected_port_n = new("reset_collected_port_n", this);
    reset_collected_port_p = new("reset_collected_port_p", this);
    alu_reset_agnt = alu_reset_agent::type_id::create("alu_reset_agnt", this);

    // Create components
    v_seqr = virtual_sequencer::type_id::create("v_seqr", this);
    alu_agnt = alu_agent::type_id::create("alu_agnt", this);
    alu_scb = alu_scoreboard::type_id::create("alu_scb", this);
    alu_sub = alu_subscriber::type_id::create("alu_sub", this);

    // Get environment configuration
    if(!uvm_config_db#(env_config)::get(this, "", "env_cfg", env_cfg))
      `uvm_fatal("NOVIF",{"env_config must be set for: ",get_full_name()});

    // Create and configure agent configurations
    rst_agnt_cfg = rst_agent_config::type_id::create("rst_agnt_cfg");
    alu_agnt_cfg = alu_agent_config::type_id::create("alu_agnt_cfg");

    rst_agnt_cfg.initialize(env_cfg.env_config_my_r_vif, env_cfg.rst_get_is_active());
    alu_agnt_cfg.initialize(env_cfg.env_config_my_vif, env_cfg.alu_get_is_active());

    // Set agent configurations in config DB
    uvm_config_db#(alu_agent_config)::set(this,"alu_agnt","alu_agnt_cfg",alu_agnt_cfg);
    uvm_config_db#(rst_agent_config)::set(this,"alu_reset_agnt","rst_agnt_cfg",rst_agnt_cfg);
  endfunction : build_phase

  //---------------------------------------
  // Connect phase
  //---------------------------------------
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    // Connect monitor to scoreboard
    alu_agnt.monitor_in.item_collected_port_in.connect(alu_scb.analysis_export_inputs);
    alu_agnt.monitor_out.item_collected_port_out.connect(alu_scb.analysis_export_actual_outputs);

    // Connect monitor to subscriber
    alu_agnt.monitor_in.item_collected_port_in.connect(alu_sub.analysis_export_inputs);
    alu_agnt.monitor_out.item_collected_port_out.connect(alu_sub.analysis_export_outputs);

    // Connect reset to all components
    alu_reset_agnt.reset_collected_port_n.connect(alu_agnt.reset_collected_export_n);
    alu_reset_agnt.reset_collected_port_p.connect(alu_agnt.reset_collected_export_p);
    
    alu_reset_agnt.reset_collected_port_n.connect(reset_collected_port_n); // reset_agent_to_env
    alu_reset_agnt.reset_collected_port_p.connect(reset_collected_port_p); // reset_agent_to_env
    
    reset_collected_port_n.connect(alu_scb.reset_collected_export); // scoreboard we may send posedge rst later
    reset_collected_port_n.connect(alu_sub.reset_collected_export); // subscriber we may send posedge rst later

    // sequencers connection
    v_seqr.seqr_ALU = alu_agnt.sequencer;
    v_seqr.seqr_RST = alu_reset_agnt.sequencer;


  endfunction : connect_phase

  //---------------------------------------
  // End of elaboration phase -  for reporting connection details
  //---------------------------------------  
  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);

    // Set verbosity level for the scoreboard
    // scoreboard_h.set_report_verbosity_level_hier(UVM_HIGH);

//     // Log connections and provided ports/exports
//     alu_agnt.driver.reset_collected_imp.get_provided_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

//     alu_agnt.driver.reset_collected_imp.get_connected_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

//     alu_reset_agnt.monitor.reset_collected_port.get_provided_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

//     alu_reset_agnt.monitor.reset_collected_port.get_connected_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

//     alu_reset_agnt.reset_collected_port.get_provided_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

//     alu_reset_agnt.reset_collected_port.get_connected_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

//     alu_agnt.reset_collected_export.get_provided_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

//     alu_agnt.reset_collected_export.get_connected_to(list);
//     `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);


    $display("ENV end_of_elaboration_phase");
  endfunction


  //---------------------------------------
  // Run phase
  //---------------------------------------
  task run_phase(uvm_phase phase);
    super.run_phase(phase);
  endtask : run_phase

  //---------------------------------------
  // Report phase
  //---------------------------------------
  function void report_phase(uvm_phase phase);
    super.report_phase(phase);
    `uvm_info(get_type_name(), "Environment Report Complete", UVM_LOW)
  endfunction : report_phase




endclass : alu_env


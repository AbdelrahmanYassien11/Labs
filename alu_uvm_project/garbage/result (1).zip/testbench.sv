//-------------------------------------------------------------------------
//				            testbench.sv
//-------------------------------------------------------------------------
//---------------------------------------------------------------
//including interfcae and testcase files
`include "alu_interface.sv"
`include "rst_interface.sv"
`include "sva_interface.sv"
`include "test_cfg.sv"
`include "alu_base_test.sv"
`include "alu_random_test.sv"
`include "alu_repition_test.sv"
`include "error_test.sv"

//---------------------------------------------------------------

module tbench_top;

  //---------------------------------------
  //clock and reset signal declaration
  //---------------------------------------
  bit clk;
  bit rst_n;
  int no_of_resets;
  int test_timeout;

  //---------------------------------------
  //clock generation
  //---------------------------------------
  always #5 clk = ~clk;

  //---------------------------------------
  //reset Generation Task
  //---------------------------------------
  task rst;
    rst_n = 0;
    #173;
    rst_n = 1;
  endtask

  //---------------------------------------
  //reset Generation
  //---------------------------------------  
  initial begin
    rst();
    //     #194;
    //     rst();
    //     #99;
    //     rst();
    //     #375;
    //     rst();
  end

  //---------------------------------------
  //interfaces instance
  //---------------------------------------
  alu_if alu_intf(clk);
  rst_if rst_intf(rst_n);
  sva_if sva_intf(alu_intf,rst_intf,rst_n,clk);

  //---------------------------------------
  //DUT instance
  //---------------------------------------
  my_ALU dut (
    .clk(clk),
    .rst_n(rst_n),
    .ALU_en(alu_intf.ALU_en),
    .a_en(alu_intf.a_en),
    .b_en(alu_intf.b_en),
    .a_op(alu_intf.a_op),
    .b_op(alu_intf.b_op),
    .A(alu_intf.A),
    .B(alu_intf.B),
    .C(alu_intf.C)
  );

  //---------------------------------------
  // Reset monitor process
  //---------------------------------------

  initial begin
    forever begin
      @(rst_intf.need_reset);
      $display("[time is %0t] Reset event detected", $time);
      rst_n = 0;
      #rst_intf.delay_global;
      rst_n = 1;
      $display("[time is %0t] Reset sequence completed", $time);
    end
  end

  //---------------------------------------
  //passing the interface handle to lower heirarchy using set method 
  //and enabling the wave dump
  //---------------------------------------
  test_config t_cfg;
  initial begin
    no_of_resets = 4;
    test_timeout = 10000;
  // Create and initialize test config
  t_cfg = test_config::type_id::create("t_cfg");
  t_cfg.set_config(UVM_ACTIVE, UVM_ACTIVE, rst_intf, alu_intf, no_of_resets, test_timeout);
  
  // Set in config DB
  uvm_config_db#(test_config)::set(uvm_root::get(),"uvm_test_top","test_cfg",t_cfg);
    //enable wave dump
    $dumpfile("dump.vcd"); 
    $dumpvars;
  end

  //---------------------------------------
  //calling reset and test
  //---------------------------------------
  initial begin 
    run_test();
  end

endmodule
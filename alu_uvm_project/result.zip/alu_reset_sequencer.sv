class alu_reset_sequencer extends uvm_sequencer#(alu_reset_seq_item);

  `uvm_component_utils(alu_reset_sequencer) 
  
  //---------------------------------------
  //constructor
  //---------------------------------------
  function new(string name, uvm_component parent);
    super.new(name,parent);
  endfunction
  
  //---------------------------------------
  // Build phase
  //---------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
  endfunction : build_phase

endclass
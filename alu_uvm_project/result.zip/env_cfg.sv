class env_config;

  // Virtual interface to the DUT
  virtual alu_if env_config_my_vif;
  virtual rst_if env_config_my_r_vif;

  uvm_active_passive_enum alu_is_active, rst_is_active;

  // Constructor for the configuration class
  function new(virtual alu_if env_config_my_vif, virtual rst_if env_config_my_r_vif, uvm_active_passive_enum alu_is_active, uvm_active_passive_enum rst_is_active);
    // Initialize the virtual interface
    this.env_config_my_vif = env_config_my_vif;
    this.env_config_my_r_vif = env_config_my_r_vif;
    this.rst_is_active = rst_is_active;
    this.alu_is_active = alu_is_active;
  endfunction : new


  // Function to get the active/passive state of the agent
  function uvm_active_passive_enum alu_get_is_active ();
    return alu_is_active;
  endfunction : alu_get_is_active  
  
  function uvm_active_passive_enum rst_get_is_active ();
    return rst_is_active;
  endfunction : rst_get_is_active  

endclass : env_config

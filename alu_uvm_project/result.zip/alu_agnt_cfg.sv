class alu_agent_config;

  // Virtual interface used for connecting the active agent to the Design Under Test (DUT)
  virtual alu_if alu_agent_config_my_vif;

  // Enumeration indicating whether the agent is active or passive
  protected uvm_active_passive_enum is_active;

  // Constructor for initializing the configuration object
  function new (virtual alu_if alu_agent_config_my_vif, uvm_active_passive_enum is_active);

    // Set the virtual interface for the configuration
    this.alu_agent_config_my_vif = alu_agent_config_my_vif;
    // Set the active/passive state of the agent
    this.is_active = is_active;

  endfunction : new

  // Function to get the active/passive state of the agent
  function uvm_active_passive_enum get_is_active ();
    return is_active;
  endfunction : get_is_active

endclass : alu_agent_config

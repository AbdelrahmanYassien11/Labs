//-------------------------------------------------------------------------
//				            alu_verification_pkg
//-------------------------------------------------------------------------
package alu_verification_pkg;

//---------------------------------------
// Type definitions
//---------------------------------------
typedef logic        [2:0] a_op_t;
typedef logic        [1:0] b_op_t;
typedef logic signed [4:0] operand_t;
typedef logic signed [5:0] result_t;

//---------------------------------------
// Common parameters
//---------------------------------------
localparam int OPERAND_WIDTH = 5;
localparam int RESULT_WIDTH = 6;


//---------------------------------------
// ALU Operation Mode ENUM
//---------------------------------------
typedef enum logic [1:0] {
  MODE_IDLE   = 2'b00,  // No operation mode (when both a_en and b_en are 0)
  MODE_A  = 2'b10,  // Operation set A (when a_en = 1, b_en = 0)
  MODE_B1 = 2'b01, // Operation set B1 (when a_en = 0, b_en = 1)
  MODE_B2 = 2'b11  // Operation set B2 (when a_en = 1, b_en = 1)
} alu_mode_t;

//---------------------------------------
// ALU Device State ENUM
//---------------------------------------
typedef enum {
  ALU_OFF,    // ALU is disabled (when ALU_en = 0)
  ALU_ON      // ALU is enabled (when ALU_en = 1)
} alu_state_t;

//---------------------------------------
// Op A ENUM
//---------------------------------------
typedef enum bit [2:0] {
  A_ADD   = 3'd0,
  A_SUB   = 3'd1,
  A_XOR   = 3'd2,
  A_AND1  = 3'd3,
  A_AND2  = 3'd4,
  A_OR    = 3'd5,
  A_XNOR  = 3'd6,
  A_NULL  = 3'd7
} op_set_a_t;

//---------------------------------------
// Op B1 ENUM (Set 1)
//---------------------------------------
typedef enum bit [1:0] {
  B_S1_NAND  = 2'd0,
  B_S1_ADD1  = 2'd1,
  B_S1_ADD2  = 2'd2,
  B_S1_NULL  = 2'd3
} op_set_b1_t;

//---------------------------------------
// Op B2 ENUM (Set 2)
//---------------------------------------
typedef enum bit [1:0] {
  B_S2_XOR     = 2'd0,
  B_S2_XNOR    = 2'd1,
  B_S2_A_SUB_1 = 2'd2,
  B_S2_B_ADD_2 = 2'd3
} op_set_b2_t;

//---------------------------------------
// Assertion counters
//---------------------------------------
int unsigned pass_count = 0;
int unsigned fail_count = 0;
int unsigned op_a_pass_count = 0;
int unsigned op_a_fail_count = 0;
int unsigned op_b1_pass_count = 0;
int unsigned op_b1_fail_count = 0;
int unsigned op_b2_pass_count = 0;
int unsigned op_b2_fail_count = 0;
int unsigned reset_pass_count = 0;
int unsigned reset_fail_count = 0;
int unsigned null_op_count = 0;
int unsigned forbidden_result_count = 0;

//---------------------------------------
// Helper Functions
//---------------------------------------

// Get the current ALU mode based on control signals
function automatic alu_mode_t get_alu_mode(logic a_en, logic b_en);
  if (!a_en && !b_en) return MODE_IDLE;
  else if (a_en && !b_en) return MODE_A;
  else if (!a_en && b_en) return MODE_B1;
  else return MODE_B2;
endfunction

// Result computation functions
function automatic result_t compute_result_a(
  input a_op_t op,
  input operand_t A,
  input operand_t B
);
  case(op)
    A_ADD:  return   {A[4],A} + {B[4],B};
    A_SUB:  return   {A[4],A} - {B[4],B};
    A_XOR:  return   {1'b0,A} ^ {1'b0,B};
    A_AND1: return   {1'b0,A} & {1'b0,B};
    A_AND2: return   {1'b0,A} & {1'b0,B};
    A_OR:   return   {1'b0,A} | {1'b0,B};
    A_XNOR: return ~({1'b0,A} ^ {1'b0,B});
    default: return '0;
  endcase
endfunction

function automatic result_t compute_result_b(
  input b_op_t op,
  input operand_t A,
  input operand_t B,
  input logic is_set2
);
  if (!is_set2) begin
    case(op)
      B_S1_NAND: return ~({1'b0,A} & {1'b0,B});
      B_S1_ADD1: return   {A[4],A} + {B[4],B};
      B_S1_ADD2: return   {A[4],A} + {B[4],B};
      default:   return '0;
    endcase
  end else begin
    case(op)
      B_S2_XOR:     return   {1'b0,A} ^ {1'b0,B};
      B_S2_XNOR:    return ~({1'b0,A} ^ {1'b0,B});
      B_S2_A_SUB_1: return   {A[4],A} - 6'd1;
      B_S2_B_ADD_2: return   {B[4],B} + 6'd2;
      default:      return '0;
    endcase
  end
endfunction

// Compute the expected result based on all control signals
function automatic result_t compute_expected_result(
  input logic ALU_en,
  input logic a_en,
  input logic b_en,
  input a_op_t a_op,
  input b_op_t b_op,
  input operand_t A,
  input operand_t B,
  input result_t prev_result
);
  result_t result;

  if (!ALU_en) return prev_result;

  case (get_alu_mode(a_en, b_en))
    MODE_IDLE:  return prev_result;
    MODE_A: result = compute_result_a(a_op, A, B);
    MODE_B1: result = compute_result_b(b_op, A, B, 1'b0);
    MODE_B2: result = compute_result_b(b_op, A, B, 1'b1);
    default: result = prev_result;
  endcase

  return result;
endfunction

// Format an error message for assertion failures
function automatic string format_error_msg(
  input string op_name,
  input operand_t A,
  input operand_t B,
  input result_t actual,
  input result_t expected
);
  return $sformatf("%s operation failed: A=%0d, B=%0d, Expected=%0d, Actual=%0d",
                   op_name, A, B, expected, actual);
endfunction

// Function to check if operation is NULL
function automatic bit is_null_operation(
  input logic a_en,
  input logic b_en,
  input a_op_t a_op,
  input b_op_t b_op
);
  // Check for A_NULL in MODE_A
  if (a_en && !b_en && a_op == A_NULL)
    return 1'b1;
  
  // Check for B_S1_NULL in MODE_B1
  if (!a_en && b_en && b_op == B_S1_NULL)
    return 1'b1;
    
  return 1'b0;
endfunction

// Function to check if result is forbidden (-32, or specific MODE_B2 forbidden values)
function automatic bit is_forbidden_result(
  input logic a_en,
  input logic b_en,
  input a_op_t a_op,
  input b_op_t b_op,
  input operand_t A,
  input operand_t B
);
  result_t result;
  
  if (a_en && !b_en && !(a_op == A_XOR || a_op == A_AND1 || a_op == A_AND2 )) begin
      result = compute_result_a(a_op, A, B);
    return (result < 0);
  end
  else if (a_en && !b_en && !(a_op == A_SUB || a_op == A_ADD )) begin
    // MODE_A
    result = compute_result_a(a_op, A, B);
    return (result == -32);
    end
  else if (a_en && !b_en && a_op == A_SUB || a_op == A_ADD ) begin
     result = compute_result_a(a_op, A, B);
      return (result == -31);
    end
  else if (!a_en && b_en && !(b_op == B_S1_ADD1 || b_op == B_S1_ADD2)) begin
    // MODE_B2
    result = compute_result_b(b_op, A, B, 1'b0);
    return (result == -32);
  end 
  else if  (!a_en && b_en && (b_op == B_S1_ADD1 || b_op == B_S1_ADD2)) begin
    // MODE_B2
    result = compute_result_b(b_op, A, B, 1'b0);
    return (result == -31);
  end
  else if (a_en && b_en && (b_op == B_S1_NAND)) begin
    result = compute_result_b(b_op, A, B, 1'b0);
    return (result > 0);
    end
  else if (a_en && b_en) begin
    // MODE_B2
    result = compute_result_b(b_op, A, B, 1'b1);
    
    // Check for general forbidden value
    if (result == -32) return 1'b1;
    
    // Check for special MODE_B2 forbidden values
    case (b_op)
      B_S2_A_SUB_1: if (result == -17) return 1'b1;
      B_S2_B_ADD_2: if (result == -14) return 1'b1;
      B_S2_XOR:     if (result < 0)    return 1'b1; 
      B_S2_XNOR:     if (result > 0) return 1'b1;
      default: return 1'b0;
    endcase
  end else begin
    // MODE_IDLE
    return 1'b0;
  end
endfunction



endpackage : alu_verification_pkg
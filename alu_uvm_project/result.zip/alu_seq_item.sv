class alu_seq_item extends uvm_sequence_item;

  local static int unsigned pkt_ID; 
  static bit cov_target, a_op_cov_trgt, b_op01_cov_trgt, b_op11_cov_trgt;
  static bit a_op_cov_repi_trgt, b_op01_cov_repi_trgt, b_op11_cov_repi_trgt;

  //---------------------------------------
  // Transaction counters
  //---------------------------------------
  static int unsigned txn_counter_expected;
  static int unsigned txn_counter_actual;

  //---------------------------------------
  // ALU Operation Mode ENUM
  //---------------------------------------
  typedef enum {
    MODE_IDLE,  // No operation mode (when both a_en and b_en are 0)
    MODE_A,     // Operation set A (when a_en = 1, b_en = 0)
    MODE_B1,    // Operation set B1 (when a_en = 0, b_en = 1)
    MODE_B2     // Operation set B2 (when a_en = 1, b_en = 1)
  } alu_mode_t;

  //---------------------------------------
  // ALU Device State ENUM
  //---------------------------------------
  typedef enum {
    ALU_OFF,    // ALU is disabled (when ALU_en = 0)
    ALU_ON      // ALU is enabled (when ALU_en = 1)
  } alu_state_t;

  alu_mode_t current_mode;
  alu_state_t device_state;

  //---------------------------------------
  // Op A ENUM
  //---------------------------------------
  typedef enum bit [2:0] {
    A_ADD   = 3'd0,
    A_SUB   = 3'd1,
    A_XOR   = 3'd2,
    A_AND1  = 3'd3,
    A_AND2  = 3'd4,
    A_OR    = 3'd5,
    A_XNOR  = 3'd6,
    A_NULL  = 3'd7
  } op_set_a_t;

  //---------------------------------------
  // Op B1 ENUM (Set 1)
  //---------------------------------------
  typedef enum bit [1:0] {
    B_S1_NAND  = 2'd0,
    B_S1_ADD1  = 2'd1,
    B_S1_ADD2  = 2'd2,
    B_S1_NULL  = 2'd3
  } op_set_b1_t;

  //---------------------------------------
  // Op B2 ENUM (Set 2)
  //---------------------------------------
  typedef enum bit [1:0] {
    B_S2_XOR     = 2'd0,
    B_S2_XNOR    = 2'd1,
    B_S2_A_SUB_1 = 2'd2,
    B_S2_B_ADD_2 = 2'd3
  } op_set_b2_t;

  op_set_a_t op_a_enum;
  op_set_b1_t op_b1_enum;
  op_set_b2_t op_b2_enum;

  //---------------------------------------
  //data and control fields
  //---------------------------------------
  rand bit                ALU_en;
  rand bit                a_en;
  rand bit                b_en;
  rand op_set_a_t         a_op;
  rand bit        [1:0]   b_op;
  rand bit signed [4:0]   A;
  rand bit signed [4:0]   B;
  bit signed [5:0]   C;

  //---------------------------------------
  //Utility and Field macros
  //---------------------------------------
  `uvm_object_utils_begin(alu_seq_item)
  `uvm_field_int(pkt_ID,UVM_ALL_ON | UVM_DEC)
  `uvm_field_enum(alu_state_t, device_state, UVM_DEFAULT)
  `uvm_field_enum(alu_mode_t, current_mode, UVM_DEFAULT)
  `uvm_field_enum(op_set_a_t, op_a_enum, UVM_DEFAULT) 
  `uvm_field_enum(op_set_b1_t, op_b1_enum, UVM_DEFAULT)
  `uvm_field_enum(op_set_b2_t, op_b2_enum, UVM_DEFAULT)
  `uvm_field_int(A,UVM_ALL_ON  | UVM_DEC)
  `uvm_field_int(B,UVM_ALL_ON  | UVM_DEC)
  `uvm_field_int(C,UVM_ALL_ON  | UVM_DEC)
  `uvm_field_int(ALU_en,UVM_ALL_ON)
  `uvm_field_int(a_en,UVM_ALL_ON)
  `uvm_field_int(b_en,UVM_ALL_ON)
  `uvm_field_int(b_op,UVM_ALL_ON)
  `uvm_object_utils_end

  //---------------------------------------
  //Constructor
  //---------------------------------------
  function new(string name = "alu_seq_item");
    super.new(name);
  endfunction

  //---------------------------------------
  // Post randomize 
  //---------------------------------------
  function void post_randomize();
    pkt_ID++;
    `uvm_info(get_full_name(), "post_randomize", UVM_HIGH)

    // Set device state (ON/OFF)
    device_state = ALU_en ? ALU_ON : ALU_OFF;

    // Set the current ALU operation mode based on control signals
    if (!a_en && !b_en) begin
      current_mode = MODE_IDLE;
    end
    else if (a_en && !b_en) begin
      current_mode = MODE_A;
      op_a_enum = a_op;
    end
    else if (!a_en && b_en) begin
      current_mode = MODE_B1;
      op_b1_enum = op_set_b1_t'(b_op);
    end
    else if (a_en && b_en) begin
      current_mode = MODE_B2;
      op_b2_enum = op_set_b2_t'(b_op);
    end
  endfunction

  //---------------------------------------
  //constraint, Enable signals distribution
  //---------------------------------------
  constraint c_enables {
    ALU_en dist {1 := 90, 0 := 10};
    ({a_en , b_en}) dist {2'b00 := 20, 2'b01 := 20, 2'b10:=20, 2'b11 := 20};
  }

  //-----------------------------------------------------
  //constraint, Valid operations based on enable signals
  //-----------------------------------------------------
  constraint c_valid_ops {
    if (a_en && !b_en) {        // MODE_A
      a_op inside {[A_ADD:A_XNOR]};
    }
      else if (!a_en && b_en) {   // MODE_B1
        b_op inside {[B_S1_NAND:B_S1_ADD2]};
      }
        else if (a_en && b_en) {    // MODE_B2
          b_op inside {[B_S2_XOR:B_S2_B_ADD_2]};
          if (b_op == B_S2_A_SUB_1) {    // A-1 operation
            B == 0;                      // B is fixed to 0
            A inside {[-15:15]};         // A can vary
          }
            else if (b_op == B_S2_B_ADD_2) { // B+2 operation
              A == 0;                       // A is fixed to 0
              B inside {[-15:15]};          // B can vary
            }
              }
              }

 //-----------------------------------------------------
 //constraint, Input value ranges
 //-----------------------------------------------------
	constraint c_input_ranges {
                A dist {[-15:15]:=1};
                B inside {[-15:15]};
              }

 //-----------------------------------------------------
 //constraint, to avoid -32 value
 //-----------------------------------------------------

constraint c_not_all_ones_xnor { // to avoid C = -32 :)
  if ((a_op == A_XNOR) || (b_op == B_S2_XNOR && a_en && b_en))
    (A^B) != 5'b11111;
}

constraint c_not_all_ones_nand { // to avoid C = -32 :)
  if (b_op == B_S1_NAND && !a_en && b_en)
    (A&B) != 5'b11111;
}
              
              endclass
`include "reference_model.sv"
`include "alu_comparator.sv"
//------------------------------------------------------------------------------
// 									Scoreboard               
//------------------------------------------------------------------------------ 
class alu_scoreboard extends uvm_scoreboard;

  // Reference model and comparator instances
  alu_reference_model reference_model_h;
  alu_comparator comparator_h;

  //---------------------------------------
  // Declare TLM component for reset
  //---------------------------------------
  uvm_analysis_export #(alu_reset_seq_item) reset_collected_export;

  // Analysis exports
  uvm_analysis_export #(alu_seq_item) analysis_export_inputs;
  uvm_analysis_export #(alu_seq_item) analysis_export_actual_outputs;

  // Register with factory
  `uvm_component_utils(alu_scoreboard)

  //---------------------------------------
  // Constructor
  //---------------------------------------
  function new(string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  //---------------------------------------
  // Build phase
  //---------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    // Create reference model and comparator
    reference_model_h = alu_reference_model::type_id::create("reference_model_h", this);
    comparator_h = alu_comparator::type_id::create("comparator_h", this);

    // Create analysis exports
    reset_collected_export = new("reset_collected_export",this);
    analysis_export_inputs = new("analysis_export_inputs", this);
    analysis_export_actual_outputs = new("analysis_export_actual_outputs", this);
  endfunction: build_phase

  //---------------------------------------
  // Connect phase
  //---------------------------------------
  function void connect_phase(uvm_phase phase);
    super.connect_phase(phase);

    // connect reset to reference model and comparator 
    reset_collected_export.connect(reference_model_h.reset_collected_export); // reference model
    reset_collected_export.connect(comparator_h.reset_collected_export); // comparator

    // Connect inputs to reference model
    analysis_export_inputs.connect(reference_model_h.analysis_export);

    // Connect actual outputs to comparator
    analysis_export_actual_outputs.connect(comparator_h.analysis_export_actual_outputs);

    // Connect reference model to comparator
    reference_model_h.analysis_port_expected_outputs.connect(comparator_h.analysis_export_expected_outputs);
  endfunction : connect_phase

  
//   ---------------------------------------
//   phase_ready_to_end phase
//   ---------------------------------------
  function void phase_ready_to_end(uvm_phase phase);
    if (phase.get_name() != "run") return;
    if (~alu_seq_item::cov_target || ~alu_reset_seq_item::resets_done) begin
      phase.raise_objection(.obj(this)); 
      fork 
        begin 
          delay_phase(phase);
        end
      join_none
    end
  endfunction

  //---------------------------------------
  // delay phase
  //---------------------------------------
  task delay_phase(uvm_phase phase);
    wait(alu_seq_item::cov_target && alu_reset_seq_item::resets_done);
    phase.drop_objection(.obj(this));
  endtask

  //---------------------------------------
  // final phase
  //---------------------------------------
  function void final_phase(uvm_phase phase);
    super.final_phase(phase);
    `uvm_info("SCOREBOARD", "Scoreboard is stopping.", UVM_LOW)
  endfunction

  //---------------------------------------
  // Report phase
  //---------------------------------------
  function void report_phase(uvm_phase phase);
    `uvm_info(get_type_name(), 
              $sformatf("\nScoreboard Report:\n\tTotal Transactions: %0d\n\tTotal Matches: %0d\n\tTotal Mismatches: %0d", 
                        comparator_h.no_transactions, comparator_h.num_matches, comparator_h.num_mismatches), 
              UVM_LOW)
    `uvm_info(get_type_name(), "Scoreboard Report Phase Complete", UVM_LOW)
  endfunction : report_phase


endclass : alu_scoreboard
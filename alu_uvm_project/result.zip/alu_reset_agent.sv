// `include "alu_reset_seq_item.sv"
// `include "alu_reset_sequencer.sv"
`include "alu_reset_driver.sv"
`include "alu_reset_monitor.sv"

class alu_reset_agent extends uvm_agent;
  
  // Virtual rst interface handle  
  virtual rst_if r_vif;
  rst_agent_config rst_agnt_cfg;
  
  //---------------------------------------
  // component instances
  //---------------------------------------
  alu_reset_driver        driver;
  alu_reset_sequencer     sequencer;
  alu_reset_monitor       monitor;

  //---------------------------------------
  // Construct TLM Component
  //---------------------------------------
  uvm_analysis_port #(alu_reset_seq_item) reset_collected_port_p;
  uvm_analysis_port #(alu_reset_seq_item) reset_collected_port_n;

  `uvm_component_utils(alu_reset_agent)

  //---------------------------------------
  // constructor
  //---------------------------------------
  function new (string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  //---------------------------------------
  // build_phase
  //---------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);

    //setter and getter for rst interface    
    if(!uvm_config_db#(rst_agent_config)::get(this, "", "rst_agnt_cfg", rst_agnt_cfg))
      `uvm_fatal("NOVIF",{"failed to get agent config: ",get_full_name()});
	
    this.is_active = rst_agnt_cfg.get_is_active(); 
    uvm_config_db#(virtual rst_if)::set(this,"driver","r_vif",rst_agnt_cfg.rst_agent_config_my_r_vif);
    uvm_config_db#(virtual rst_if)::set(this,"monitor","r_vif",rst_agnt_cfg.rst_agent_config_my_r_vif);
  
    reset_collected_port_p = new ("reset_collected_port_p",this);
    reset_collected_port_n = new ("reset_collected_port_n",this);

    monitor	    = alu_reset_monitor::type_id::create("monitor", this);

    //     creating driver and sequencer only for ACTIVE agent
    if(get_is_active() == UVM_ACTIVE) begin
      driver    = alu_reset_driver::type_id::create("driver", this);
      sequencer = alu_reset_sequencer::type_id::create("sequencer", this);
    end
  endfunction : build_phase

  //   ---------------------------------------  
  //   connect_phase - connecting the driver and sequencer port
  //   ---------------------------------------
  function void connect_phase(uvm_phase phase);
    //     reset_collected_port.connect(monitor.reset_collected_port);
    monitor.reset_collected_port_n.connect(reset_collected_port_n);
    monitor.reset_collected_port_p.connect(reset_collected_port_p);
    if(get_is_active() == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
    end
  endfunction : connect_phase

endclass : alu_reset_agent
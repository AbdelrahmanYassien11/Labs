// `include "alu_seq_item.sv"
// `include "alu_sequencer.sv"
`include "alu_sequence.sv"
`include "alu_driver.sv"
`include "alu_monitor_in.sv"
`include "alu_monitor_out.sv"

class alu_agent extends uvm_agent;
  uvm_port_list list;
  //---------------------------------------
  // component instances
  //---------------------------------------
  alu_driver        driver;
  alu_sequencer     sequencer;
  alu_monitor_in    monitor_in;
  alu_monitor_out   monitor_out;

  // Virtual ALU interface handle  
  virtual alu_if vif;
  alu_agent_config alu_agnt_cfg;
  
  //---------------------------------------
  // Declare TLM component for reset
  //---------------------------------------
  uvm_analysis_export #(alu_reset_seq_item) reset_collected_export_n;
  uvm_analysis_export #(alu_reset_seq_item) reset_collected_export_p;

  `uvm_component_utils(alu_agent)

  //---------------------------------------
  // constructor
  //---------------------------------------
  function new (string name, uvm_component parent);
    super.new(name, parent);
  endfunction : new

  //---------------------------------------
  // build_phase
  //---------------------------------------
  function void build_phase(uvm_phase phase);
    super.build_phase(phase);
    
    
    //setter and getter for alu interface
    if(!uvm_config_db#(alu_agent_config)::get(this, "", "alu_agnt_cfg", alu_agnt_cfg))
      `uvm_fatal("NOVIF",{"agent config be set for: ",get_full_name()});
    
    is_active = alu_agnt_cfg.get_is_active();
    uvm_config_db#(virtual alu_if)::set(this,"driver","vif",alu_agnt_cfg.alu_agent_config_my_vif);
    uvm_config_db#(virtual alu_if)::set(this,"monitor_in","vif",alu_agnt_cfg.alu_agent_config_my_vif);
    uvm_config_db#(virtual alu_if)::set(this,"monitor_out","vif",alu_agnt_cfg.alu_agent_config_my_vif);
   
    reset_collected_export_n = new ("reset_collected_export_n",this); 
    reset_collected_export_p = new ("reset_collected_export_p",this); 
    monitor_in  = alu_monitor_in::type_id::create("monitor_in", this);
    monitor_out = alu_monitor_out::type_id::create("monitor_out", this);

    //creating driver and sequencer only for ACTIVE agent
    if(get_is_active() == UVM_ACTIVE) begin
      driver    = alu_driver::type_id::create("driver", this);
      sequencer = alu_sequencer::type_id::create("sequencer", this);
    end
  endfunction : build_phase

  //---------------------------------------  
  // connect_phase - connecting the driver and sequencer port
  //---------------------------------------
  function void connect_phase(uvm_phase phase);
    reset_collected_export_n.connect(sequencer.resetflag_imp);
    reset_collected_export_n.connect(driver.reset_collected_imp_n);// driver
    reset_collected_export_n.connect(monitor_in.reset_collected_imp_n);// mon_in
    reset_collected_export_n.connect(monitor_out.reset_collected_imp_n);// mon_out

    reset_collected_export_p.connect(driver.reset_collected_imp_p);// driver
    reset_collected_export_p.connect(monitor_in.reset_collected_imp_p);// mon_in
    reset_collected_export_p.connect(monitor_out.reset_collected_imp_p);// mon_out

    if(get_is_active() == UVM_ACTIVE) begin
      driver.seq_item_port.connect(sequencer.seq_item_export);
    end
  endfunction : connect_phase

  /*
  //---------------------------------------
  // End of elaboration phase -  for reporting connection details
  //---------------------------------------  
  function void end_of_elaboration_phase(uvm_phase phase);
    super.end_of_elaboration_phase(phase);

    // Set verbosity level for the scoreboard
    // scoreboard_h.set_report_verbosity_level_hier(UVM_HIGH);

    // Log connections and provided ports/exports
    driver.reset_collected_imp.get_provided_to(list);
    `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);

    driver.reset_collected_imp.get_connected_to(list);
    `uvm_info(get_name(), $sformatf("%p", list), UVM_LOW);
    $display("alu agent end_of_elaboration_phase");
  endfunction
  */

endclass : alu_agent